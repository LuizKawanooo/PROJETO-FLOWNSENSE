package fatec.flowsense.backend.controller.dto;

public record LoginRequest(String email, String password){

}
