package fatec.flowsense.backend.controller.dto;

public record CreateUserDto(String username, String email, String password) {
}
